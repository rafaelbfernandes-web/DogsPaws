<?php
require 'conexao.php';
exigir_login();
$uid = $_SESSION['uid'];
$pets = $pdo->prepare('SELECT id, nome FROM pets WHERE usuario_id = ? ORDER BY nome'); $pets->execute([$uid]); $pets = $pets->fetchAll();
$servicos = $pdo->query('SELECT * FROM servicos ORDER BY id')->fetchAll();
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) { $erros[] = 'A sessão expirou. Envie de novo.'; }
    elseif (isset($_POST['cancelar'])) {
        $pdo->prepare('DELETE FROM agendamentos WHERE id = ? AND usuario_id = ?')->execute([(int)$_POST['cancelar'], $uid]);
        flash('Horário cancelado.'); header('Location: agenda.php'); exit;
    } else {
        $pet = (int)($_POST['pet'] ?? 0); $sv = (int)($_POST['servico'] ?? 0);
        $data = $_POST['data'] ?? ''; $hora = $_POST['hora'] ?? '';
        $petOk = array_filter($pets, fn($p) => (int)$p['id'] === $pet);
        $serv = current(array_filter($servicos, fn($s) => (int)$s['id'] === $sv));
        $d = DateTime::createFromFormat('Y-m-d', $data);
        if (!$petOk) $erros[] = 'Escolha um dos seus pets.';
        if (!$serv) $erros[] = 'Escolha o serviço.';
        if (!$d || $d->format('Y-m-d') !== $data || $data < date('Y-m-d')) $erros[] = 'Escolha uma data de hoje em diante.';
        elseif ($serv && !in_array((int)$d->format('w'), array_map('intval', explode(',', $serv['dias_semana'])), true))
            $erros[] = $serv['nome'] . ' acontece: ' . mb_strtolower($serv['descricao']) . '.';
        if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $hora)) $erros[] = 'Informe um horário válido.';
        if (!$erros) {
            try {
                $pdo->prepare('INSERT INTO agendamentos (usuario_id, pet_id, servico_id, data, hora) VALUES (?,?,?,?,?)')->execute([$uid, $pet, $sv, $data, $hora]);
                flash('Horário marcado!'); header('Location: agenda.php'); exit;
            } catch (PDOException $e) { $erros[] = 'Esse pet já tem algo marcado nesse horário.'; }
        }
    }
}
$q = $pdo->prepare('SELECT a.id, a.data, a.hora, s.nome AS servico, p.nome AS pet FROM agendamentos a JOIN servicos s ON s.id=a.servico_id JOIN pets p ON p.id=a.pet_id WHERE a.usuario_id=? AND a.data>=CURDATE() ORDER BY a.data, a.hora');
$q->execute([$uid]); $marcados = $q->fetchAll();
$nome = count($pets) === 1 ? $pets[0]['nome'] : 'seu pet';
$titulo = 'Agenda | Mr. Paws'; $pagina = 'agenda'; include 'includes/cabecalho.php';
?>
<section>
<h2>Agenda diária do <?= e($nome) ?></h2>
<p class="lead">O que está marcado e o que ainda dá para marcar.</p>
<div class="two">
<article class="panel"><h3>Próximos horários</h3>
<?php if (!$marcados): ?><p>Nada marcado ainda.</p><?php else: ?>
<table class="tbl"><thead><tr><th>Dia</th><th>Hora</th><th>Serviço</th><th></th></tr></thead><tbody>
<?php foreach ($marcados as $m): ?>
<tr><td><?= date('d/m', strtotime($m['data'])) ?></td><td><?= substr($m['hora'], 0, 5) ?></td><td><?= e($m['servico']) ?>, <?= e($m['pet']) ?></td>
<td><form method="post" style="margin:0"><input type="hidden" name="csrf" value="<?= csrf() ?>"><button class="btn out" name="cancelar" value="<?= (int)$m['id'] ?>" style="padding:4px 14px">Cancelar</button></form></td></tr>
<?php endforeach; ?></tbody></table><?php endif; ?>
</article>
<?php if (!$pets): ?>
<article class="panel"><h3>Marcar horário</h3><p>Cadastre um pet primeiro.</p><div class="row"><a class="btn" href="pet.php">Cadastrar meu pet</a></div></article>
<?php else: ?>
<form class="panel" method="post"><input type="hidden" name="csrf" value="<?= csrf() ?>">
<h3>Marcar horário</h3>
<?php if ($erros): ?><ul class="erros"><?php foreach ($erros as $x) echo '<li>' . e($x) . '</li>'; ?></ul><?php endif; ?>
<label for="pet">Pet</label><select id="pet" name="pet" required><?php foreach ($pets as $p) echo '<option value="' . (int)$p['id'] . '">' . e($p['nome']) . '</option>'; ?></select>
<label for="sv">Serviço</label><select id="sv" name="servico" required><?php foreach ($servicos as $s) echo '<option value="' . (int)$s['id'] . '">' . e($s['nome']) . ' (' . e(mb_strtolower($s['descricao'])) . ')</option>'; ?></select>
<label for="dt">Dia</label><input id="dt" name="data" type="date" min="<?= date('Y-m-d') ?>" required>
<label for="hr">Hora</label><input id="hr" name="hora" type="time" required>
<div class="row"><button class="btn" type="submit">Marque já!</button></div>
</form>
<?php endif; ?>
</div>
</section>
<?php include 'includes/rodape.php'; ?>
