<?php require 'conexao.php'; $titulo = 'Atendimento | Mr. Paws'; $pagina = 'atendimento'; include 'includes/cabecalho.php'; ?>
<section>
<h2>Atendimento</h2>
<p class="lead">Escolha o que você precisa.</p>
<div class="panel" style="margin-top:24px">
<div class="menu" id="menu">
<button type="button" aria-pressed="false">Consulta</button><button type="button" aria-pressed="false">Produtos</button><button type="button" aria-pressed="false">Castração</button>
<button type="button" aria-pressed="false">Alimentos</button><button type="button" data-href="agenda.php">Agenda</button><button type="button" aria-pressed="false">Adoção</button>
</div>
<p class="msg" id="msg" role="status"></p>
<div class="links"><button class="btn out" type="button" data-t="Raças">Raças</button><button class="btn out" type="button" data-t="Perfil">Perfil</button><button class="btn out" type="button" data-t="Ajuda">Ajuda</button><button class="btn out" type="button" data-t="Política de cookies">Política de cookies</button></div>
</div>
</section>
<?php include 'includes/rodape.php'; ?>
