CREATE DATABASE IF NOT EXISTS db_mrpaws CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_mrpaws;

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(160) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  contato VARCHAR(20) NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  nome VARCHAR(80) NOT NULL,
  raca VARCHAR(80) NOT NULL,
  porte ENUM('Pequeno','Médio','Grande') NOT NULL,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE servicos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(60) NOT NULL UNIQUE,
  dias_semana VARCHAR(20) NOT NULL COMMENT '0=domingo ... 6=sabado',
  descricao VARCHAR(80) NOT NULL,
  preco DECIMAL(8,2) NOT NULL
);

CREATE TABLE agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  pet_id INT NOT NULL,
  servico_id INT NOT NULL,
  data DATE NOT NULL,
  hora TIME NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (pet_id, data, hora),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE,
  FOREIGN KEY (servico_id) REFERENCES servicos(id)
);

INSERT INTO servicos (nome, dias_semana, descricao, preco) VALUES
('Banho', '1,2,3,4,5', 'De segunda a sexta', 99.99),
('Tosa', '2,4', 'Terça e quinta', 99.99),
('Vacinação', '1,3,5', 'Segunda, quarta e sexta', 99.99);
