<?php
require 'conexao.php';
if (logado()) { header('Location: pet.php'); exit; }
$erros = []; $em = $ct = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) $erros[] = 'A sessão expirou. Envie de novo.';
    $em = trim($_POST['email'] ?? ''); $se = $_POST['senha'] ?? ''; $ct = trim($_POST['contato'] ?? '');
    if (!filter_var($em, FILTER_VALIDATE_EMAIL)) $erros[] = 'Email inválido.';
    if (strlen($se) < 8) $erros[] = 'A senha precisa de pelo menos 8 caracteres.';
    if (!preg_match('/^[0-9 ()+-]{8,20}$/', $ct)) $erros[] = 'Telefone inválido.';
    if (!$erros) {
        $q = $pdo->prepare('SELECT id FROM usuarios WHERE email = ?'); $q->execute([$em]);
        if ($q->fetch()) { $erros[] = 'Esse email já tem cadastro. Tente entrar.'; }
        else {
            $pdo->prepare('INSERT INTO usuarios (email, senha_hash, contato) VALUES (?,?,?)')
                ->execute([$em, password_hash($se, PASSWORD_DEFAULT), $ct]);
            session_regenerate_id(true);
            $_SESSION['uid'] = (int)$pdo->lastInsertId();
            flash('Conta criada. Agora cadastre seu pet.');
            header('Location: pet.php'); exit;
        }
    }
}
$titulo = 'Cadastro | Mr. Paws'; $pagina = 'cadastro'; include 'includes/cabecalho.php';
?>
<section>
<h2>Cadastro</h2>
<p class="lead">Primeiro você, depois o seu pet.</p>
<form class="panel" method="post" style="margin-top:28px;max-width:520px">
<input type="hidden" name="csrf" value="<?= csrf() ?>">
<h3>Sua conta</h3>
<?php if ($erros): ?><ul class="erros"><?php foreach ($erros as $x) echo '<li>' . e($x) . '</li>'; ?></ul><?php endif; ?>
<label for="em">Login</label><input id="em" name="email" type="email" placeholder="email@exemplo.com" value="<?= e($em) ?>" required>
<label for="se">Senha</label><input id="se" name="senha" type="password" placeholder="Mínimo de 8 caracteres" minlength="8" required>
<label for="ct">Contato</label><input id="ct" name="contato" type="tel" placeholder="19 91234-5678" value="<?= e($ct) ?>" required>
<div class="row"><button class="btn" type="submit">Concluir</button><a class="btn out" href="login.php">Já tenho conta</a></div>
</form>
</section>
<?php include 'includes/rodape.php'; ?>
