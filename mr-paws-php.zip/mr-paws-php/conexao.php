<?php
// Conexão com o MySQL (PDO). Ajuste usuário e senha para o seu ambiente.
session_start();

$host = 'localhost';
$banco = 'db_mrpaws';
$usuario = 'root';
$senha = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$banco;charset=utf8mb4", $usuario, $senha, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Não foi possível conectar ao banco. Confira o conexao.php e importe o banco.sql.');
}

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function logado() { return !empty($_SESSION['uid']); }
function flash($m) { $_SESSION['flash'] = $m; }
function exigir_login() {
    if (!logado()) { flash('Entre na sua conta para continuar.'); header('Location: login.php'); exit; }
}
function csrf() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_ok() { return isset($_POST['csrf']) && hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']); }
