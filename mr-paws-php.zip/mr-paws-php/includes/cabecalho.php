<?php $p = $pagina ?? ''; $at = fn($n) => $p === $n ? ' aria-current="page"' : ''; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title><?= e($titulo ?? 'Mr. Paws Pet shop') ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;800&family=Figtree:wght@400;600;700&display=swap">
<link rel="stylesheet" href="css/style.css">
</head>
<body data-flash="<?= e($_SESSION['flash'] ?? '') ?>">
<?php unset($_SESSION['flash']); ?>
<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
<g id="s1"><path d="M24 28C8 34 8 70 18 78c5 3 9-6 10-16z"/><path d="M76 28c16 6 16 42 6 50-5 3-9-6-10-16z"/><ellipse cx="50" cy="52" rx="30" ry="32"/></g>
<g id="s2"><path d="M22 14l18 22-24 14z"/><path d="M78 14L60 36l24 14z"/><ellipse cx="50" cy="54" rx="31" ry="30"/></g>
<symbol id="dog" viewBox="-6 -6 112 112"><use href="#s1" fill="#fff" stroke="#fff" stroke-width="16" stroke-linejoin="round"/><use href="#s1" fill="#F4A96A" stroke="#231A15" stroke-width="5" stroke-linejoin="round"/><circle cx="38" cy="45" r="4" fill="#231A15"/><circle cx="62" cy="45" r="4" fill="#231A15"/><ellipse cx="50" cy="58" rx="8" ry="6" fill="#231A15"/><path d="M40 70q10 8 20 0" fill="none" stroke="#231A15" stroke-width="4" stroke-linecap="round"/></symbol>
<symbol id="corgi" viewBox="-6 -6 112 112"><use href="#s2" fill="#fff" stroke="#fff" stroke-width="16" stroke-linejoin="round"/><use href="#s2" fill="#F4A96A" stroke="#231A15" stroke-width="5" stroke-linejoin="round"/><path d="M50 26c-6 14-12 22-12 34 0 8 24 8 24 0 0-12-6-20-12-34z" fill="#FFF6C8"/><circle cx="36" cy="46" r="4" fill="#231A15"/><circle cx="64" cy="46" r="4" fill="#231A15"/><ellipse cx="50" cy="62" rx="7" ry="5" fill="#231A15"/><path d="M42 72q8 7 16 0" fill="none" stroke="#231A15" stroke-width="4" stroke-linecap="round"/></symbol>
</defs></svg>

<header><div class="bar">
<a class="logo" href="index.php"><svg><use href="#dog"/></svg>Mr. Paws</a>
<nav aria-label="Principal">
<a href="servicos.php"<?= $at('servicos') ?>>Serviços</a>
<a href="<?= logado() ? 'pet.php' : 'cadastro.php' ?>"<?= $at('cadastro') ?>>Cadastro</a>
<a href="atendimento.php"<?= $at('atendimento') ?>>Atendimento</a>
<a href="agenda.php"<?= $at('agenda') ?>>Agenda</a>
</nav>
<?php if (logado()): ?>
<form action="logout.php" method="post" style="margin:0"><input type="hidden" name="csrf" value="<?= csrf() ?>"><button class="bone" type="submit">Sair da conta</button></form>
<?php else: ?>
<a class="bone" href="login.php">Entrar</a>
<?php endif; ?>
</div></header>
<main id="topo">
