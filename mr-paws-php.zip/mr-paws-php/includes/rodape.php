<?php if ($fechar_main ?? true) echo '</main>'; ?>
<footer>Mr. Paws Pet shop</footer>
<div id="toast" role="status"></div>
<script src="js/app.js"></script>
</body>
</html>
