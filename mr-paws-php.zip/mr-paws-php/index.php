<?php require 'conexao.php'; $titulo = 'Mr. Paws Pet shop'; $pagina = 'inicio'; $fechar_main = false; include 'includes/cabecalho.php'; ?>
<section class="hero">
<div>
<h1>Ele já achou a poça. Marque o banho.</h1>
<p>A Mr. Paws faz banho, tosa e vacinação. Você cadastra seu pet uma vez e marca os horários por aqui.</p>
<div class="cta"><a class="btn" href="<?= logado() ? 'pet.php' : 'cadastro.php' ?>">Cadastrar meu pet</a><a href="servicos.php">Ver dias e preços</a></div>
</div>
<div class="dogs" aria-hidden="true"><svg class="d1" viewBox="-6 -6 112 112"><use href="#dog"/></svg><svg class="d2" viewBox="-6 -6 112 112"><use href="#corgi"/></svg></div>
</section>

<section>
<h2>Você já passou por isso</h2>
<p class="lead">Tentou lembrar quando foi a última vacina e achou só uma foto do cachorro dormindo. Ligou para marcar o banho e ninguém atendeu. Descobriu que tosa só tem terça e quinta depois de chegar numa quarta. Pet shop não precisa ser uma prova de paciência.</p>
<div class="steps">
<div class="step"><h3>Cadastre você e seu pet</h3><p>Email, senha e telefone. Depois nome, raça e porte do bicho.</p></div>
<div class="step"><h3>Escolha serviço e dia</h3><p>Banho, tosa ou vacinação. Cada um custa R$ 99,99.</p></div>
<div class="step"><h3>Leve o pet</h3><p>A agenda do dia fica no seu painel, sem caçar mensagem antiga.</p></div>
</div>
</section>
</main>
<div class="final"><div>
<h2>Faça o cadastro hoje. Marque quando precisar.</h2>
<p style="max-width:48ch;margin:0 0 24px">O cadastro é só isso: seus dados e os do seu pet. Nada de horário marcado hoje. Ficou com dúvida? Chama no [telefone ou WhatsApp].</p>
<a class="btn" href="<?= logado() ? 'pet.php' : 'cadastro.php' ?>">Cadastrar meu pet</a>
</div></div>
<?php include 'includes/rodape.php'; ?>
