var tt, T = document.getElementById('toast');
function toast(s) {
  T.textContent = s; T.classList.add('on');
  clearTimeout(tt); tt = setTimeout(function () { T.classList.remove('on'); }, 2800);
}
if (document.body.dataset.flash) toast(document.body.dataset.flash);

var M = document.getElementById('msg'), bs = document.querySelectorAll('#menu button');
bs.forEach(function (b) {
  b.addEventListener('click', function () {
    if (b.dataset.href) { location.href = b.dataset.href; return; }
    bs.forEach(function (x) { x.setAttribute('aria-pressed', 'false'); });
    b.setAttribute('aria-pressed', 'true');
    M.textContent = b.textContent + ' selecionado. Em breve você marca direto por aqui.';
  });
});
document.querySelectorAll('[data-t]').forEach(function (b) {
  b.addEventListener('click', function () { toast(b.dataset.t + ' ainda vai ganhar uma página.'); });
});
