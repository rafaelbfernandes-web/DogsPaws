<?php
require 'conexao.php';
if (logado()) { header('Location: agenda.php'); exit; }
$erro = ''; $em = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $em = trim($_POST['email'] ?? '');
    $q = $pdo->prepare('SELECT id, senha_hash FROM usuarios WHERE email = ?'); $q->execute([$em]);
    $u = $q->fetch();
    if (csrf_ok() && $u && password_verify($_POST['senha'] ?? '', $u['senha_hash'])) {
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$u['id'];
        header('Location: agenda.php'); exit;
    }
    $erro = 'Email ou senha incorretos.';
}
$titulo = 'Entrar | Mr. Paws'; $pagina = 'login'; include 'includes/cabecalho.php';
?>
<section>
<h2>Entrar</h2>
<p class="lead">Use o email e a senha do cadastro.</p>
<form class="panel" method="post" style="margin-top:28px;max-width:520px">
<input type="hidden" name="csrf" value="<?= csrf() ?>">
<?php if ($erro): ?><ul class="erros"><li><?= e($erro) ?></li></ul><?php endif; ?>
<label for="em">Login</label><input id="em" name="email" type="email" placeholder="email@exemplo.com" value="<?= e($em) ?>" required>
<label for="se">Senha</label><input id="se" name="senha" type="password" required>
<div class="row"><button class="btn" type="submit">Entrar</button><a class="btn out" href="cadastro.php">Criar conta</a></div>
</form>
</section>
<?php include 'includes/rodape.php'; ?>
