<?php
require 'conexao.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_ok()) {
    $_SESSION = [];
    session_destroy();
    session_start();
    flash('Você saiu da conta.');
}
header('Location: index.php');
