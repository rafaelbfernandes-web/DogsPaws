<?php
require 'conexao.php';
exigir_login();
$erros = []; $v = ['nome' => '', 'raca' => '', 'porte' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) $erros[] = 'A sessão expirou. Envie de novo.';
    $v = ['nome' => trim($_POST['nome'] ?? ''), 'raca' => trim($_POST['raca'] ?? ''), 'porte' => $_POST['porte'] ?? ''];
    if ($v['nome'] === '' || mb_strlen($v['nome']) > 80) $erros[] = 'Informe o nome do animal.';
    if ($v['raca'] === '' || mb_strlen($v['raca']) > 80) $erros[] = 'Informe a raça.';
    if (!in_array($v['porte'], ['Pequeno', 'Médio', 'Grande'], true)) $erros[] = 'Escolha o porte.';
    if (!$erros) {
        $pdo->prepare('INSERT INTO pets (usuario_id, nome, raca, porte) VALUES (?,?,?,?)')
            ->execute([$_SESSION['uid'], $v['nome'], $v['raca'], $v['porte']]);
        flash('Pet cadastrado!');
        header('Location: pet.php'); exit;
    }
}
$q = $pdo->prepare('SELECT * FROM pets WHERE usuario_id = ? ORDER BY id DESC'); $q->execute([$_SESSION['uid']]);
$pets = $q->fetchAll();
$titulo = 'Informações do pet | Mr. Paws'; $pagina = 'cadastro'; include 'includes/cabecalho.php';
?>
<section>
<h2>Informações do pet</h2>
<p class="lead">Quem vai tomar banho?</p>
<div class="two">
<form class="panel" method="post">
<input type="hidden" name="csrf" value="<?= csrf() ?>">
<h3>Novo pet</h3>
<?php if ($erros): ?><ul class="erros"><?php foreach ($erros as $x) echo '<li>' . e($x) . '</li>'; ?></ul><?php endif; ?>
<label for="np">Nome do animal</label><input id="np" name="nome" placeholder="Ex.: Thor" value="<?= e($v['nome']) ?>" required>
<label for="rc">Raça</label><input id="rc" name="raca" placeholder="Ex.: Corgi" value="<?= e($v['raca']) ?>" required>
<label for="pt">Porte</label>
<select id="pt" name="porte" required><option value="">Escolha o porte</option>
<?php foreach (['Pequeno', 'Médio', 'Grande'] as $o) echo '<option' . ($v['porte'] === $o ? ' selected' : '') . '>' . $o . '</option>'; ?></select>
<div class="row"><button class="btn" type="submit">Concluir</button><a class="btn out" href="servicos.php">Cancelar</a></div>
</form>
<div class="panel">
<h3>Seus pets</h3>
<?php if (!$pets): ?><p>Nenhum pet cadastrado ainda.</p><?php endif; ?>
<?php foreach ($pets as $p): ?>
<div class="tag"><b><?= e($p['nome']) ?></b><span><?= e($p['raca']) ?>, porte <?= e(mb_strtolower($p['porte'])) ?></span></div>
<?php endforeach; ?>
<?php if ($pets): ?><div class="row"><a class="btn alt" href="agenda.php">Marcar horário</a></div><?php endif; ?>
</div>
</div>
</section>
<?php include 'includes/rodape.php'; ?>
