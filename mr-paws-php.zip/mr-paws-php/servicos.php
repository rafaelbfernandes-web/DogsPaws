<?php
require 'conexao.php';
$servicos = $pdo->query('SELECT * FROM servicos ORDER BY id')->fetchAll();
$dias = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
$hoje = (int)date('w');
function chip($s, $hoje, $dias) {
    $d = array_map('intval', explode(',', $s['dias_semana']));
    if (in_array($hoje, $d, true)) return '<span class="chip">Tem hoje</span>';
    for ($k = 1; $k < 8; $k++) if (in_array(($hoje + $k) % 7, $d, true)) break;
    return '<span class="chip off">Volta ' . ($k === 1 ? 'amanhã' : 'na ' . $dias[($hoje + $k) % 7]) . '</span>';
}
$agora = [];
if (logado()) {
    $q = $pdo->prepare('SELECT a.hora, s.nome AS servico, p.nome AS pet FROM agendamentos a JOIN servicos s ON s.id=a.servico_id JOIN pets p ON p.id=a.pet_id WHERE a.usuario_id=? AND a.data=CURDATE() ORDER BY a.hora');
    $q->execute([$_SESSION['uid']]); $agora = $q->fetchAll();
}
$titulo = 'Serviços | Mr. Paws'; $pagina = 'servicos'; include 'includes/cabecalho.php';
?>
<section>
<h2>Serviços e agenda</h2>
<p class="lead">O que está disponível hoje aparece em destaque. O resto diz quando volta.</p>
<div class="bento">
<?php foreach ($servicos as $i => $s): ?>
<article class="tile<?= $i === 0 ? ' big' : '' ?>">
<?php if ($i === 0): ?><svg viewBox="-6 -6 112 112" aria-hidden="true"><use href="#corgi"/></svg><?php endif; ?>
<?= chip($s, $hoje, $dias) ?><h3><?= e($s['nome']) ?></h3><p class="days"><?= e($s['descricao']) ?></p>
<div class="price">R$ <?= number_format($s['preco'], 2, ',', '.') ?></div></article>
<?php endforeach; ?>
<article class="tile wide"><h3>Agenda de hoje</h3>
<?php if (!logado()): ?><p><a href="login.php"><u>Entre na sua conta</u></a> para ver os horários do seu pet.</p>
<?php elseif (!$agora): ?><p>Nada marcado para hoje. <a href="agenda.php"><u>Marcar horário</u></a></p>
<?php else: ?><table class="tbl"><tbody><?php foreach ($agora as $r) echo '<tr><td>' . substr($r['hora'], 0, 5) . '</td><td>' . e($r['servico']) . ', ' . e($r['pet']) . '</td></tr>'; ?></tbody></table><?php endif; ?>
</article>
<article class="tile wide who"><div class="donut" role="img" aria-label="Cachorro 50%, gato 35%, outros 15%"></div>
<div><h3>Quem vem</h3><p>Cachorro é maioria, mas 35% dos pets atendidos são gatos.</p>
<ul class="legend"><li><i style="background:var(--sun)"></i>Cachorro 50%</li><li><i style="background:var(--fur)"></i>Gato 35%</li><li><i style="background:var(--water)"></i>Outros 15%</li></ul></div></article>
</div>
</section>
<?php include 'includes/rodape.php'; ?>
